#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "types.h"
#include "encode.h"   /* MAX_FILE_SUFFIX, BMP_HEADER_SIZE */

#define DEFAULT_DECODED_NAME "decoded"

typedef struct _DecodeInfo
{
    /* Stego image */
    char *stego_image_fname;
    FILE *fptr_stego_image;

    /* Output (decoded) file */
    char output_fname[256];
    char *user_output_base;      /* name given by user (may be NULL / with or without extension) */
    FILE *fptr_output;
    char extn_output_file[MAX_FILE_SUFFIX];
    long size_output_file;
} DecodeInfo;

/* Read and validate Decode args from argv */
Status read_and_validate_decode_args(int argc, char *argv[], DecodeInfo *decInfo);

/* Perform the decoding */
Status do_decoding(DecodeInfo *decInfo);

/* Open stego image */
Status open_decode_files(DecodeInfo *decInfo);

/* Decode helpers */
Status decode_magic_string(const char *magic_string, DecodeInfo *decInfo);
Status decode_secret_file_extn(DecodeInfo *decInfo);
Status decode_secret_file_size(DecodeInfo *decInfo);
Status decode_secret_file_data(DecodeInfo *decInfo);

Status decode_data_from_image(char *data, int size, FILE *fptr_stego_image);
Status decode_int_from_lsb(int *value, FILE *fptr_stego_image);
char   decode_byte_from_lsb(const char *image_buffer);

#endif
