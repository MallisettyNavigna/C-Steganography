#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* ---------- helpers ---------- */

static const char *get_extension(const char *fname)
{
    const char *dot = strrchr(fname, '.');
    return dot ? dot : "";
}

static int has_bmp_extension(const char *fname)
{
    const char *e = get_extension(fname);
    return strcmp(e, ".bmp") == 0;
}

OperationType check_operation_type(char *argv[])
{
    if (argv[1] == NULL)
        return e_unsupported;
    if (strcmp(argv[1], "-e") == 0)
        return e_encode;
    if (strcmp(argv[1], "-d") == 0)
        return e_decode;
    return e_unsupported;
}

/* ---------- image / file info ---------- */

/* width * height * 3 (bytes available for RGB data) */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;

    fseek(fptr_image, 18, SEEK_SET);
    if (fread(&width, sizeof(int), 1, fptr_image) != 1 ||
        fread(&height, sizeof(int), 1, fptr_image) != 1)
        return 0;

    printf("INFO: Image width = %u, height = %u\n", width, height);
    return width * height * 3;
}

uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);
    uint size = (uint)ftell(fptr);
    rewind(fptr);
    return size;
}

/* ---------- argument validation ---------- */

/* ./lsb_steg -e <.bmp> <secret file> [output.bmp] */
Status read_and_validate_encode_args(int argc, char *argv[], EncodeInfo *encInfo)
{
    if (argc < 4)
    {
        fprintf(stderr, "ERROR: Missing arguments\n");
        return e_failure;
    }

    if (!has_bmp_extension(argv[2]))
    {
        fprintf(stderr, "ERROR: Source image \"%s\" must be a .bmp file\n", argv[2]);
        return e_failure;
    }
    encInfo->src_image_fname = argv[2];

    const char *extn = get_extension(argv[3]);
    if (*extn == '\0')
    {
        fprintf(stderr, "ERROR: Secret file \"%s\" has no extension\n", argv[3]);
        return e_failure;
    }
    if (strlen(extn) >= MAX_FILE_SUFFIX)
    {
        fprintf(stderr, "ERROR: Secret file extension \"%s\" is too long (max %d chars)\n",
                extn, MAX_FILE_SUFFIX - 1);
        return e_failure;
    }
    encInfo->secret_fname = argv[3];
    strcpy(encInfo->extn_secret_file, extn);

    if (argc >= 5)
    {
        if (!has_bmp_extension(argv[4]))
        {
            fprintf(stderr, "ERROR: Output file \"%s\" must be a .bmp file\n", argv[4]);
            return e_failure;
        }
        encInfo->stego_image_fname = argv[4];
    }
    else
    {
        printf("INFO: Output File not mentioned. Creating %s as default\n", DEFAULT_STEGO_NAME);
        encInfo->stego_image_fname = DEFAULT_STEGO_NAME;
    }

    if (strcmp(encInfo->src_image_fname, encInfo->stego_image_fname) == 0)
    {
        fprintf(stderr, "ERROR: Output file must differ from the source image\n");
        return e_failure;
    }
    return e_success;
}

/* ---------- file handling ---------- */

Status open_files(EncodeInfo *encInfo)
{
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);
        return e_failure;
    }
    printf("INFO: Opened %s\n", encInfo->src_image_fname);

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "rb");
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);
        return e_failure;
    }
    printf("INFO: Opened %s\n", encInfo->secret_fname);

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "wb");
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);
        return e_failure;
    }
    printf("INFO: Opened %s\n", encInfo->stego_image_fname);

    return e_success;
}

/* ---------- capacity ---------- */

/*
 * Layout in the image (each data bit uses 1 image byte):
 *   magic string | extn length (int) | extn | file size (int) | file data
 */
Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);

    printf("INFO: Checking for %s size\n", encInfo->secret_fname);
    if (encInfo->size_secret_file == 0)
    {
        fprintf(stderr, "ERROR: %s is empty\n", encInfo->secret_fname);
        return e_failure;
    }
    printf("INFO: Done. Not Empty\n");

    printf("INFO: Checking for %s capacity to handle %s\n",
           encInfo->src_image_fname, encInfo->secret_fname);

    long bytes_needed = (long)strlen(MAGIC_STRING)
                      + (long)sizeof(int)
                      + (long)strlen(encInfo->extn_secret_file)
                      + (long)sizeof(int)
                      + encInfo->size_secret_file;

    if (bytes_needed * 8 > (long)encInfo->image_capacity)
    {
        fprintf(stderr, "ERROR: \"%s\" doesn't have the capacity to encode \"%s\"\n",
                encInfo->src_image_fname, encInfo->secret_fname);
        return e_failure;
    }
    printf("INFO: Done. Found OK\n");
    return e_success;
}

/* ---------- low level encoding ---------- */

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char header[BMP_HEADER_SIZE];

    rewind(fptr_src_image);
    if (fread(header, 1, BMP_HEADER_SIZE, fptr_src_image) != BMP_HEADER_SIZE)
        return e_failure;
    if (fwrite(header, 1, BMP_HEADER_SIZE, fptr_dest_image) != BMP_HEADER_SIZE)
        return e_failure;
    return e_success;
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for (int i = 0; i < 8; i++)
    {
        int bit = (data >> (7 - i)) & 1;          /* MSB first */
        image_buffer[i] = (image_buffer[i] & ~1) | bit;
    }
    return e_success;
}

Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char buf[8];

    for (int i = 0; i < size; i++)
    {
        if (fread(buf, 1, 8, fptr_src_image) != 8)
            return e_failure;
        encode_byte_to_lsb(data[i], buf);
        if (fwrite(buf, 1, 8, fptr_stego_image) != 8)
            return e_failure;
    }
    return e_success;
}

Status encode_int_to_lsb(int value, FILE *fptr_src, FILE *fptr_dest)
{
    char buf[32];

    if (fread(buf, 1, 32, fptr_src) != 32)
        return e_failure;
    for (int i = 0; i < 32; i++)
    {
        int bit = ((unsigned int)value >> (31 - i)) & 1;
        buf[i] = (buf[i] & ~1) | bit;
    }
    return fwrite(buf, 1, 32, fptr_dest) == 32 ? e_success : e_failure;
}

Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    return encode_data_to_image((char *)magic_string, (int)strlen(magic_string),
                                encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    int len = (int)strlen(file_extn);

    if (encode_int_to_lsb(len, encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
        return e_failure;
    return encode_data_to_image((char *)file_extn, len,
                                encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    return encode_int_to_lsb((int)file_size, encInfo->fptr_src_image, encInfo->fptr_stego_image);
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    rewind(encInfo->fptr_secret);

    for (long i = 0; i < encInfo->size_secret_file; i++)
    {
        if (fread(encInfo->secret_data, 1, MAX_SECRET_BUF_SIZE, encInfo->fptr_secret) != MAX_SECRET_BUF_SIZE)
            return e_failure;
        if (encode_data_to_image(encInfo->secret_data, MAX_SECRET_BUF_SIZE,
                                 encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
            return e_failure;
    }
    return e_success;
}

Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char buf[4096];
    size_t n;

    while ((n = fread(buf, 1, sizeof buf, fptr_src)) > 0)
        if (fwrite(buf, 1, n, fptr_dest) != n)
            return e_failure;
    return e_success;
}

/* ---------- top level ---------- */

#define STEP(msg, call)                                              \
    do {                                                             \
        printf("INFO: " msg "\n");                                   \
        if ((call) == e_failure) {                                   \
            fprintf(stderr, "ERROR: Failed during: " msg "\n");      \
            return e_failure;                                        \
        }                                                            \
        printf("INFO: Done\n");                                      \
    } while (0)

Status do_encoding(EncodeInfo *encInfo)
{
    printf("INFO: ## Encoding Procedure Started ##\n");

    if (check_capacity(encInfo) == e_failure)
        return e_failure;

    STEP("Copying Image Header",
         copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image));
    STEP("Encoding Magic String Signature",
         encode_magic_string(MAGIC_STRING, encInfo));
    STEP("Encoding Secret File Extension",
         encode_secret_file_extn(encInfo->extn_secret_file, encInfo));
    STEP("Encoding Secret File Size",
         encode_secret_file_size(encInfo->size_secret_file, encInfo));
    STEP("Encoding Secret File Data",
         encode_secret_file_data(encInfo));
    STEP("Copying Left Over Data",
         copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image));

    printf("INFO: ## Encoding Done Successfully ##\n");
    return e_success;
}
