#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "common.h"

Status read_and_validate_decode_args(int argc, char *argv[], DecodeInfo *decInfo)
{
    if (argc < 3)
    {
        fprintf(stderr, "ERROR: Missing arguments\n");
        return e_failure;
    }

    const char *e = strrchr(argv[2], '.');
    if (e == NULL || strcmp(e, ".bmp") != 0)
    {
        fprintf(stderr, "ERROR: Stego image \"%s\" must be a .bmp file\n", argv[2]);
        return e_failure;
    }
    decInfo->stego_image_fname = argv[2];
    decInfo->user_output_base = (argc >= 4) ? argv[3] : NULL;
    return e_success;
}

Status open_decode_files(DecodeInfo *decInfo)
{
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "rb");
    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);
        return e_failure;
    }
    printf("INFO: Opened %s\n", decInfo->stego_image_fname);

    /* skip BMP header, data starts right after it */
    if (fseek(decInfo->fptr_stego_image, BMP_HEADER_SIZE, SEEK_SET) != 0)
        return e_failure;
    return e_success;
}

char decode_byte_from_lsb(const char *image_buffer)
{
    unsigned char ch = 0;
    for (int i = 0; i < 8; i++)
        ch = (ch << 1) | (image_buffer[i] & 1);
    return (char)ch;
}

Status decode_data_from_image(char *data, int size, FILE *fptr_stego_image)
{
    char buf[8];
    for (int i = 0; i < size; i++)
    {
        if (fread(buf, 1, 8, fptr_stego_image) != 8)
            return e_failure;
        data[i] = decode_byte_from_lsb(buf);
    }
    return e_success;
}

Status decode_int_from_lsb(int *value, FILE *fptr_stego_image)
{
    char buf[32];
    unsigned int v = 0;

    if (fread(buf, 1, 32, fptr_stego_image) != 32)
        return e_failure;
    for (int i = 0; i < 32; i++)
        v = (v << 1) | (buf[i] & 1);
    *value = (int)v;
    return e_success;
}

Status decode_magic_string(const char *magic_string, DecodeInfo *decInfo)
{
    char buf[64];
    int len = (int)strlen(magic_string);

    if (len >= (int)sizeof buf ||
        decode_data_from_image(buf, len, decInfo->fptr_stego_image) == e_failure)
        return e_failure;
    return memcmp(buf, magic_string, len) == 0 ? e_success : e_failure;
}

Status decode_secret_file_extn(DecodeInfo *decInfo)
{
    int len;

    if (decode_int_from_lsb(&len, decInfo->fptr_stego_image) == e_failure)
        return e_failure;
    if (len < 0 || len >= MAX_FILE_SUFFIX)
        return e_failure;
    if (decode_data_from_image(decInfo->extn_output_file, len, decInfo->fptr_stego_image) == e_failure)
        return e_failure;
    decInfo->extn_output_file[len] = '\0';
    return e_success;
}

Status decode_secret_file_size(DecodeInfo *decInfo)
{
    int size;
    if (decode_int_from_lsb(&size, decInfo->fptr_stego_image) == e_failure || size < 0)
        return e_failure;
    decInfo->size_output_file = size;
    return e_success;
}

Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char ch;
    for (long i = 0; i < decInfo->size_output_file; i++)
    {
        if (decode_data_from_image(&ch, 1, decInfo->fptr_stego_image) == e_failure)
            return e_failure;
        if (fputc(ch, decInfo->fptr_output) == EOF)
            return e_failure;
    }
    return e_success;
}

/* Build output file name: <base><extn>. Uses user's base name without any extension. */
static void build_output_name(DecodeInfo *decInfo)
{
    char base[200];

    if (decInfo->user_output_base)
    {
        strncpy(base, decInfo->user_output_base, sizeof base - 1);
        base[sizeof base - 1] = '\0';
        char *dot = strrchr(base, '.');
        char *slash = strrchr(base, '/');
        if (dot && (!slash || dot > slash))
            *dot = '\0';
    }
    else
    {
        strcpy(base, DEFAULT_DECODED_NAME);
        printf("INFO: Output File not mentioned. Creating %s%s as default\n",
               base, decInfo->extn_output_file);
    }
    snprintf(decInfo->output_fname, sizeof decInfo->output_fname, "%s%s",
             base, decInfo->extn_output_file);
}

Status do_decoding(DecodeInfo *decInfo)
{
    printf("INFO: ## Decoding Procedure Started ##\n");
    printf("INFO: Opening required files\n");
    if (open_decode_files(decInfo) == e_failure)
        return e_failure;

    printf("INFO: Decoding Magic String Signature\n");
    if (decode_magic_string(MAGIC_STRING, decInfo) == e_failure)
    {
        fprintf(stderr, "ERROR: Magic string mismatch - \"%s\" has no hidden data\n",
                decInfo->stego_image_fname);
        return e_failure;
    }
    printf("INFO: Done\n");

    printf("INFO: Decoding Output File Extension\n");
    if (decode_secret_file_extn(decInfo) == e_failure)
    {
        fprintf(stderr, "ERROR: Failed to decode file extension\n");
        return e_failure;
    }
    printf("INFO: Done\n");

    build_output_name(decInfo);
    decInfo->fptr_output = fopen(decInfo->output_fname, "wb");
    if (decInfo->fptr_output == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->output_fname);
        return e_failure;
    }
    printf("INFO: Opened %s\n", decInfo->output_fname);
    printf("INFO: Done. Opened all required files\n");

    printf("INFO: Decoding File Size\n");
    if (decode_secret_file_size(decInfo) == e_failure)
    {
        fprintf(stderr, "ERROR: Failed to decode file size\n");
        return e_failure;
    }
    printf("INFO: Done\n");

    printf("INFO: Decoding File Data\n");
    if (decode_secret_file_data(decInfo) == e_failure)
    {
        fprintf(stderr, "ERROR: Failed to decode file data (image truncated?)\n");
        return e_failure;
    }
    printf("INFO: Done\n");

    printf("INFO: ## Decoding Done Successfully ##\n");
    return e_success;
}
