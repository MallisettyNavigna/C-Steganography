/* main.c - driver: ./lsb_steg -e / -d */
#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

static void print_usage(const char *prog)
{
    printf("%s: Encoding: %s -e <.bmp_file> <.text_file> [output file]\n", prog, prog);
    printf("%s: Decoding: %s -d <.bmp_file> [output file]\n", prog, prog);
}

static void close_encode(EncodeInfo *e)
{
    if (e->fptr_src_image)   fclose(e->fptr_src_image);
    if (e->fptr_secret)      fclose(e->fptr_secret);
    if (e->fptr_stego_image) fclose(e->fptr_stego_image);
}

int main(int argc, char *argv[])
{
    OperationType op = check_operation_type(argv);

    if (argc < 2 || op == e_unsupported)
    {
        print_usage(argv[0]);
        return 1;
    }

    if (op == e_encode)
    {
        EncodeInfo enc = {0};

        if (argc < 4)
        {
            printf("%s: Encoding: %s -e <.bmp file> <.txt file> [output file]\n", argv[0], argv[0]);
            return 1;
        }
        if (read_and_validate_encode_args(argc, argv, &enc) == e_failure)
        {
            print_usage(argv[0]);
            return 1;
        }
        printf("INFO: Opening required files\n");
        if (open_files(&enc) == e_failure)
        {
            close_encode(&enc);
            return 1;
        }
        printf("INFO: Done\n");

        Status st = do_encoding(&enc);
        close_encode(&enc);
        if (st == e_failure)
        {
            remove(enc.stego_image_fname);   /* don't leave a corrupt output */
            return 1;
        }
    }
    else /* e_decode */
    {
        DecodeInfo dec = {0};

        if (read_and_validate_decode_args(argc, argv, &dec) == e_failure)
        {
            print_usage(argv[0]);
            return 1;
        }
        Status st = do_decoding(&dec);
        if (dec.fptr_stego_image) fclose(dec.fptr_stego_image);
        if (dec.fptr_output)      fclose(dec.fptr_output);
        if (st == e_failure)
        {
            if (dec.fptr_output) remove(dec.output_fname);
            return 1;
        }
    }
    return 0;
}
